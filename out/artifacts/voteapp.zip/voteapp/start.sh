#!/bin/bash
java -cp "lib/*:." com.dcits.VoteApplication
